
public class Grade {
	
	private GradeType type;
	private int score;
	
	public Grade(GradeType type, int score) throws Exception {
		this.type = type;
		setScore(score);
	}


	public GradeType getType() {
		return type;
	}


	public void setType(GradeType type) {
		this.type = type;
	}


	public int getScore() {
		return score;
	}


	public void setScore(int score) throws Exception {
		validateScore(score);
		this.score = score;
	}


	public String toString() {
		return "Grade [type=" + type + ", score=" + score + "]";
	}
	
	private void validateScore(int score) throws Exception {
		if(score < 40 || score > 100) {
			throw new Exception("Invalid score");
		}
	}
	
	
	
	
}
