
public class SchoolStatistics {

	public static void main(String[] args) {
		
		School school = new School(5);
		
		public static String getSchoolData(School school);
		public static void getSchoolAverage(School school);
		public static void getAll31StudentsAndAvg(School school);
		public static void getAvgAgeStudents(School school);
	}

}
