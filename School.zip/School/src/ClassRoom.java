import java.util.Arrays;
import java.util.Random;
import java.util.UUID;

public class ClassRoom {
	Random r1 = new Random();
	private final int numOfStudents = 15;
	private String className;
	private Teacher teacher;
	private Student[] students;

	public ClassRoom() {
		this.className = generateName();
		this.teacher = generateTeacher();
		this.students = generateStudents();
	}

	public String getClassName() {
		return className;
	}

	public void setName(String name) {
		this.className = name;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Student[] getStudents() {
		return students;
	}

	public void setStudents(Student[] students) {
		this.students = students;
	}

	public String toString() {
		return "ClassRoom [name=" + className + ", teacher=" + teacher + ", students=" + Arrays.toString(students) + "]";
	}

	private String generateClassName() {
		return UUID.randomUUID().toString().substring(0, 5);
		
	}

	private Teacher generateTeacher() {
		Teacher teacher = null;
		try {
			teacher = new Teacher(className, numOfStudents, className);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return teacher;
	}

	private Student[] generateStudents() {

		Student[] students = new Student[numOfStudents];

		for (int i = 0; i < students.length; i++) {
			try {
				students[i] = new Student(Person.getName(), r1.nextInt(101) + 20);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return students;
	}

}
