
public class utills {

	public static String getSchoolData(School school) {
		String schoolData = "The school has " + School.getClassRooms() + " classes ";

		for (int i = 0; i < School.getClassRooms().length; i++) {
			schoolData += getClassData(School.getClassRooms()[i]);
		}

		return "The name of the class is " + ClassRoom.getClassName() + " the name of the teacher is " + 1 + " "
				+ "and he teaches " + 1 + " ";
	}

	// public static String get

	public static void getSchoolAverage(School school) {
		int schoolAverage = 0;
		int numOfStudents = 0;
		for (int i = 0; i < school.getClassRooms().length; i++) {
			for (int j = 0; j < ClassRoom.getStudents().length; j++) {
			}
			numOfStudents++;
			for (int l = 0; l < Student.getGrades(); l++) {

			}
		}
	}

	public static void getAll31StudentsAndAvg(School school) {
		for(int i = 0 ; i < school.getClassRooms().length; i++) {
			for(int j = 0 ; j < ClassRoom.getStudents(); j++) {
				for(int l = 0 ; l < Student.getGrades.length(); l++)
				int All31Student = 0;
				
				
			}
		}
	}

	public static void getAvgAgeStudents(School school) {
		int numOfStudents = 0;
		int StudentsAge = 0;
		for (int i = 0; i < school.getClassRooms().length; i++) {
			for (int j = 0; j < ClassRoom.getStudents(); j++) {
				Student[] students = ClassRoom.getStudents();
				for (int l = 0; students.length; l++) {
					numOfStudents++;
					StudentsAge++;
				}
			}
		}
		int avg = StudentsAge / StudentsAge;
		System.out.println(avg);
	}
}
