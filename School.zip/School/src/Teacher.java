
public class Teacher extends Person {

	private String profession;

	public Teacher(String name, int age, String profession) throws Exception {
		super(name, age);
		setProfession(profession);
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) throws Exception {
		validateProfessions(profession);
		this.profession = profession;
	}

	public String toString() {
		return "Teacher [profession=" + profession + "]";
	}

	private void validateProfessions(String profession) throws Exception {
		if (!profession.equals("Math") && !profession.equals("Chemistry") && !profession.equals("Geography")
				&& !profession.equals("Literature") && !profession.equals("Physics") && !profession.equals("Sports")) {
			throw new Exception("Invalid profession");
		}
	}

}
