import java.util.Arrays;

public class School {
	
	private int numOfClasses = 5;
	private  ClassRoom[] classRooms;

	public School(int numOfClasses) {
		this.classRooms = generatClassRooms(numOfClasses);
	}

	public ClassRoom[] getClassRooms() {
		return classRooms;
	}

	public void setClassRooms(ClassRoom[] classRooms) {
		this.classRooms = classRooms;
	}

	public String toString() {
		return "School [classRooms=" + Arrays.toString(classRooms) + "]";
	}
	
	private ClassRoom[] generatClassRooms(int numOfClasses) {
		ClassRoom[] classRooms = new ClassRoom[numOfClasses];
		
		for(int i = 0; i < classRooms.length; i++) {
			classRooms[i] = new ClassRoom();
		}
		
		return classRooms;
	}
	
}
