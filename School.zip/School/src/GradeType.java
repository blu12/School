
public enum GradeType {

	MATH, CHEMISTRY, GEOGRAPHY, LITERATURE, PHYSICS, SPORTS;

	private static String[] gradeTypes = { "MATH", "CHEMISTRY", "GEOGRAPHY", "LITERATURE", "PHYSICS", "SPORTS" };

	public static String[] getGradeTypes() {
		return gradeTypes;
	}
}
