import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;

public class Student extends Person {
	Random r1 = new Random();
	private final int numOfGrades = 6;
	private Grade[] grades;

	public Student(String name, int age) throws Exception {
		super(name, age);
		this.grades = generateGrades();
	}

	public Grade[] getGrades() {
		return grades;
	}

	public void setGrades(Grade[] grades) {
		this.grades = grades;
	}

	public String toString() {
		return "Student [grades=" + Arrays.toString(grades) + "]";
	}

	private Grade[] generateGrades() {
		Grade[] grades = new Grade[numOfGrades];
		
		for(int i = 0; i < grades.length; i++) {
			GradeType.valueOf(
					GradeType.getGradeTypes()[r1.nextInt(GradeType.getGradeTypes().length)]), 
			(r1.nextInt(61) + 40);
		}
		
		return grades;
	}

}
