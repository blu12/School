import java.util.UUID;

public class Person {

	private static String name;
	private int age;

	public Person(String name, int age) throws Exception {
		name = generateName();
		setAge(age);
	}

	public static String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) throws Exception {
		validateAge(age);
		this.age = age;
	}

	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	private void validateAge(int age) throws Exception {
		if (age < 20 || age > 120) {
			throw new Exception("Invalid age");
		}
	}

	private String generateName() {
		return UUID.randomUUID().toString().substring(0, 5);
	}

}
